﻿using Lib.Common;
using Newtonsoft.Json;
using ServiceLayer.Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;

namespace ServiceLayer
{
    public class WeatherInfo : InterfaceWeatherInfo
    {
        #region Implementation of IAutoSubmitService

        /// <summary>
        /// Fetch Weather Information
        /// </summary>
        public void FetchWeatherInformation()
        {
            //log started message
            string fullMethodName = string.Concat("WebJob_WeatherInfo", ".", MethodBase.GetCurrentMethod().Name);
            List<LogEntity> logEntities = new List<LogEntity>();
            //log entities
            try
            {              
               
                    LoggerHelper.Info(fullMethodName, LogMethodState.Started, logEntities);
                    GetCityDetails();
                
            }
            catch (Exception ex)
            {
                
                LoggerHelper.Fatal(fullMethodName, "Error ocurred while fetching information", logEntities, ex);
            }

        }

        #endregion
        private void GetCityDetails()
        {
            //log started message
            string fullMethodName = string.Concat("Service", ".", MethodBase.GetCurrentMethod().Name);
            List<LogEntity> logEntities = new List<LogEntity>();
            //log entities
            try
            {
                LoggerHelper.Info(fullMethodName, LogMethodState.Started, logEntities);

                string path = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;
                string filePath = path + "/CityDetails/city.list.json";
                string timeStamp = string.Empty;
                string detinationpath = string.Empty;
                //Open the file              
                var stream = File.OpenText(filePath);

                //Read the file 
                var json = File.ReadAllText(filePath);

                var myclass = Newtonsoft.Json.JsonConvert.DeserializeObject<List<CityDetail>>(json);
                foreach (var item in myclass)
                {

                    timeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                    detinationpath = path + "/CityWiseDailyReport/" + item.name + timeStamp + ".json";
                    using (var client = new WebClient()) //WebClient  
                    {
                        LoggerHelper.Info("Weather Api", LogMethodState.Started, logEntities);
                        client.Headers.Add("Content-Type:application/json"); //Content-Type  
                        client.Headers.Add("Accept:application/json");
                        var result = client.DownloadString("https://api.openweathermap.org/data/2.5/weather?APPID=aa69195559bd4f88d79f9aadeb77a8f6&id=" + item.id); //URI  
                        string jsonData = JsonConvert.SerializeObject(result, Formatting.None);
                        LoggerHelper.Info("Weather Api", LogMethodState.Completed, logEntities);


                        //writing the file into the location in Json format so as to reduce the overhead of serializing and deserailizing for manipulatting histroy data
                        System.IO.File.WriteAllText(detinationpath, jsonData);
                        LoggerHelper.Info(fullMethodName, LogMethodState.Completed, logEntities);
                    }

                    Console.WriteLine("Generating Report Please wait....");
                    Console.ReadLine();
                   

                }

            }
            catch (Exception ex)
            {
                LoggerHelper.Fatal(fullMethodName, "Error ocurred while writing weather information", logEntities, ex);
            }
        }
    }
}
