﻿using Lib.Common;
using ServiceLayer;
using ServiceLayer.Interface;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace WeatherReportConsoleApp
{
    // This program can be publised as Azure webjobs or can add scheduler
    class Program
    {
        static void Main(string[] args)
        {
            string fullMethodName = string.Concat("WeatherReportConsoleApp.Program", ".", MethodBase.GetCurrentMethod().Name);
            List<Lib.Common.LogEntity> logEntities = new List<Lib.Common.LogEntity>();

            try
            {
                LoggerHelper.Info(fullMethodName, LogMethodState.Started, logEntities);
                //var host = new JobHost();
                //// The following code ensures that the WebJob will be running continuously
                //host.RunAndBlock();
                InterfaceWeatherInfo weatherInfo = new WeatherInfo();
                weatherInfo.FetchWeatherInformation();
            }
            catch (Exception ex)
            {
                LoggerHelper.Fatal(fullMethodName, "Error ocurred while Running Weather Report WebJob or Scheduler", logEntities, ex);
            }
        }
    }
}
