﻿namespace Lib.Common
{
    public enum LogMethodState
    {
        Started,
        Completed
    }
}