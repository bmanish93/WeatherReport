﻿

namespace Lib.Common
{
    public class LogEntity
    {
        public string Name { get; set; }

        public string Value { get; set; }

    }
}