﻿using NLog;
using System;
using System.Collections.Generic;
using System.Text;
using Lib.Common;
namespace Lib.Common
{
    public class LoggerHelper
    {
        #region Declarations

        private static readonly NLog.Logger _logger = null;

        #endregion Declarations

        #region Constructor

        static LoggerHelper()
        {
            _logger = NLog.LogManager.GetCurrentClassLogger();
            //_logger = NLog.LogManager.GetLogger("databaselogger");
        }

        #endregion Constructor

        #region Info Log

        /// <summary>
        /// It just writes the exception info
        /// </summary>
        /// <param name="ex"> Exception object ex</param>
        public static void Info(Exception ex)
        {
            try
            {
                if (_logger != null)
                    _logger.Info(ex);
            }
            catch { }
        }

        /// <summary>
        /// It logs the Info logs using string format
        /// </summary>        
        /// <param name="format">String format</param>
        /// <param name="args">Format Arguments</param>
        public static void Info(string format, params object[] args)
        {
            try
            {
                if (_logger != null)
                    _logger.Info(format, args);
            }
            catch { }
        }

        /// <summary>
        /// log the message
        /// </summary>
        /// <param name="fullMethodName"></param>
        /// <param name="logMethodState"></param>
        /// <param name="Id"></param>
        /// <param name="name"></param>
        public static void Info(string fullMethodName, LogMethodState logMethodState, List<Lib.Common.LogEntity> logEntities)
        {
            string methodState = logMethodState.ToString();
            StringBuilder parameterMessageStringBuilder = new StringBuilder();
            if (logEntities == null)
            {
                logEntities = new List<LogEntity>();
            }

            if (logEntities != null)
            {
                foreach (Lib.Common.LogEntity eachLogEntity in logEntities)
                {
                    parameterMessageStringBuilder.Append(eachLogEntity.Name);
                    parameterMessageStringBuilder.Append(": ");
                    parameterMessageStringBuilder.Append(eachLogEntity.Value);
                    parameterMessageStringBuilder.Append(", ");
                }
            }

            string parameterMessage = parameterMessageStringBuilder.ToString();

            // log the started Message
            string baseLogMessage = "{0} {1}=>. Parameters: {2}";

            //_logger.Log()
            string logMessage = string.Format(baseLogMessage, fullMethodName, methodState, parameterMessage);
            //_logger.Info(logMessage);

            LogEventInfo logEvent = new LogEventInfo(LogLevel.Info, _logger.Name, logMessage);
            _logger.Log(typeof(LoggerHelper), logEvent);

            ////_logger.Info(logMessage);
            //Exception ex = new Exception("Test exception");
            //_logger.ErrorException("error occurred", ex);
        }

        #endregion Info Log

        #region Fatal Log

        /// <summary>
        /// It just writes the exception info
        /// </summary>
        /// <param name="ex"> Exception object ex</param>
        public static void Fatal(Exception ex)
        {
            try
            {
                if (_logger != null)
                    _logger.Fatal(ex);
            }
            catch { }
        }

        /// <summary>
        /// It logs the Info logs using string format
        /// </summary>        
        /// <param name="format">String format</param>
        /// <param name="args">Format Arguments</param>
        public static void Fatal(string format, params object[] args)
        {
            try
            {
                if (_logger != null)
                    _logger.Fatal(format, args);
            }
            catch { }
        }

        public static void Info(object fullMethodName, LogMethodState started, List<LogEntity> logEntities)
        {
            throw new NotImplementedException();
        }

        internal static void Fatal(object fullMethodName, string v, object logEntities, Exception ex)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// log the message
        /// </summary>
        /// <param name="fullMethodName"></param>
        /// <param name="logMethodState"></param>
        /// <param name="Id"></param>
        /// <param name="name"></param>
        public static void Fatal(string fullMethodName, string logMessage, List<Lib.Common.LogEntity> logEntities, Exception ex)
        {
            StringBuilder parameterMessageStringBuilder = new StringBuilder();
            // check if logEntities is null
            if (logEntities == null)
            {
                logEntities = new List<LogEntity>();
            }

            // logEntities is not null and it has count
            if (logEntities != null && logEntities.Count > 0)
            {
                foreach (Lib.Common.LogEntity eachLogEntity in logEntities)
                {
                    parameterMessageStringBuilder.Append(eachLogEntity.Name);
                    parameterMessageStringBuilder.Append(": ");
                    parameterMessageStringBuilder.Append(eachLogEntity.Value);
                    parameterMessageStringBuilder.Append(", ");
                }
            }

            string parameterMessage = parameterMessageStringBuilder.ToString();

            // log the started Message
            string baseLogMessage = "{0} {1}=>. Parameters: {2}, Exception Message:{2}, Stack Trace:{3}";
            logMessage = string.Format(baseLogMessage, fullMethodName, logMessage, parameterMessage, ex.ToString(), ex.StackTrace.ToString());

            LogEventInfo logEvent = new LogEventInfo(LogLevel.Fatal, _logger.Name, logMessage);
            logEvent.Exception = ex;
            _logger.Log(typeof(LoggerHelper), logEvent);

            //_logger.Fatal(logMessage);
        }

        #endregion  Fatal Log
        
    }
}
